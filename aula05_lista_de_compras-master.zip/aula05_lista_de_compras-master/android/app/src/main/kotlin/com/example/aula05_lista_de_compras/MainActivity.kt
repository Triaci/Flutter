package com.example.aula05_lista_de_compras

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
