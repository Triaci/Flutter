# aula13_miscelaneous

A new Flutter project.

## Getting Started

 - Instalar dependências
 - INTENTS
   - Adicionar as intent-filter no AndroidManifest.xml
 - SHARE
   - Adicionar minifyEnabled e shrinkResources como false em build.gradle (android.buildType.debug)
   - Ajustar compileSdkVersion
 - NOTIFICATION
  - Alterar o icone em android.app.src.main.res.mipmap-* (caso queira personalizar a notificação)