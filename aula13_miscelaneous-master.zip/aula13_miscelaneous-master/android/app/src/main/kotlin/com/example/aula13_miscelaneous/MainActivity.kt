package com.example.aula13_miscelaneous

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
