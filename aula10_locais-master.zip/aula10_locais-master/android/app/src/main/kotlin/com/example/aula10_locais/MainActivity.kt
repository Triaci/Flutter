package com.example.aula10_locais

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
